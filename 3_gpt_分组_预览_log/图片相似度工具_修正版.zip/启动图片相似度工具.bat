@echo off
chcp 65001 >nul
set "SCRIPT=%~dp0image_similarity_renamer.py"
echo ========================================
echo 图片相似度分组与重命名工具
 echo 当前脚本：%SCRIPT%
echo ========================================
echo.
if not exist "%SCRIPT%" (
  echo [ERROR] 找不到 image_similarity_renamer.py
  pause
  exit /b 1
)
python -c "import sys; print('Python:', sys.version); print('Script:', r'%SCRIPT%')"
echo.
python "%SCRIPT%"
echo.
echo 程序已退出，错误代码：%ERRORLEVEL%
pause
